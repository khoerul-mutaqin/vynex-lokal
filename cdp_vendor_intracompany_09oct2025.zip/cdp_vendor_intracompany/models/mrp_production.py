from odoo import models, api, fields, _
from odoo.exceptions import UserError

class MRP(models.Model):
    _inherit = 'mrp.production'

    cdp_origin_order = fields.Char("Origin Order", copy=False)
