from odoo import models, api, fields, _
from odoo.exceptions import UserError


class PurchaseOrder(models.Model):
    _inherit = "purchase.order"

    cdp_origin_order = fields.Char("Origin Order", copy=False)

    def inter_company_create_sale_order(self, company):
        sale_orders = (
            self.env["sale.order"]
            .sudo()
            .search([("auto_purchase_order_id", "=", self.id)])
        )
        if sale_orders:
            return True
        return super(PurchaseOrder, self).inter_company_create_sale_order(company)


class PurchaseOrderLine(models.Model):
    _inherit = "purchase.order.line"

    def _create_or_update_picking(self):
        return True
