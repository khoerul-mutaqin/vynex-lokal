{
    "name": "Vendor IntraCompany",
    "version": "18.0.0.0.0",
    "author": "Falinwa",
    "license": "AGPL-3",
    "category": "Sales",
    "depends": ["sale_purchase_inter_company_rules"],
    "data": [
        "views/sale_order_views.xml",
        "views/purchase_order_views.xml"
    ],
    "installable": True,
}
