from odoo import models, api, fields, _
from odoo.exceptions import UserError

class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    cdp_origin_order = fields.Char("Origin Order")