from odoo import models, api, fields, _
from odoo.exceptions import UserError

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    cdp_origin_order = fields.Char("Origin Order")
    cdp_created_intra_company = fields.Boolean(default=False)

    def _action_confirm(self):
        self.order_line.sudo()._action_launch_stock_rule()
        return super(SaleOrder, self)._action_confirm()

    def action_generate_intra_company(self):
        for sale in self:
            if sale.state == 'draft':
                sale.action_confirm()
            
            sale.generate_intercompany_chain()

    def generate_intercompany_chain(self):
        self.cdp_created_intra_company = True
        sale_order = self.env['sale.order']
        purchase_order = self.env['purchase.order']

        queue = [self]
        while queue:
            current_so = queue.pop(0)
            if current_so.state == 'draft':
                current_so.cdp_origin_order = self.name
                current_so.sudo().action_confirm()

            pos = purchase_order.sudo().search([
                ('origin', 'ilike', current_so.name),
                ('state', '!=', 'cancel')
            ])

            for po in pos:
                if po.state in ['draft', 'sent']:
                    po.cdp_origin_order = self.name
                    po.sudo().button_confirm()

                so_created = sale_order.sudo().search([
                    ('client_order_ref', 'ilike', po.name),
                    ('state', 'in', ['draft'])
                ])
                queue.extend(so_created)


    def cdp_update_intra_company(self):
        sale_orders = self.env['sale.order'].sudo().search([('cdp_origin_order', 'ilike', self.name)])
        purchase_orders = self.env['purchase.order'].sudo().search([('cdp_origin_order', 'ilike', self.name)])
        fields_sync = self.env["cdp.fields.sync"].sudo()

        for po in purchase_orders:
            for sol in self.order_line.sudo():
                pol = po.order_line.filtered(lambda l: l.name == sol.name)
                if not pol:
                    line_data = sol.order_id._prepare_purchase_order_line_data(
                        sol,
                        sol.order_id.date_order,
                        po.company_id,
                    )
                    line_data.update(
                        {
                            "price_unit": sol.price_unit,
                            "order_id": po.id,
                        }
                    )
                    self.env["purchase.order.line"].sudo().create(line_data)
                    continue
                pol = pol[0]
                fields_sync.fal_run_sync_record(
                    "sale.order.line", "purchase.order.line", sol.sudo(), pol.sudo()
                )
            fields_sync.fal_run_sync_record(
                "sale.order", "purchase.order", self.sudo(), po.sudo()
            )
        for so in sale_orders:
            for sol in self.order_line.sudo():
                sol_2 = so.order_line.filtered(lambda l: l.name == sol.name)
                if not sol_2:
                    line_data = {
                        "name": sol.name,
                        "product_uom_qty": sol.product_uom_qty,
                        "product_id": (
                            sol.product_id.id if sol.product_id else False
                        ),
                        "product_uom": (
                            sol.product_id.uom_id.id
                            if sol.product_id
                            else sol.product_uom.id
                        ),
                        "company_id": so.company_id.id,
                        "display_type": sol.display_type,
                        "order_id": so.id,
                    }

                    self.env["sale.order.line"].sudo().create(line_data)
                    continue

                sol_2 = sol_2[0]
                fields_sync.fal_run_sync_record(
                    "sale.order.line", "sale.order.line", sol.sudo(), sol_2.sudo()
                )
            fields_sync.fal_run_sync_record(
                "sale.order", "sale.order", self.sudo(), so.sudo()
            )